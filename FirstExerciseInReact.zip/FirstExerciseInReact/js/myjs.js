class VALUES extends React.Component{
	constructor (){
		super();
		 this.state = { w: 200, h:200 };
		 this.handleChangeW = this.handleChangeW.bind(this);
		 this.handleChangeH = this.handleChangeH.bind(this);
	}
	
	handleChangeW(e){
	this.setState({w:e.target.value});
		
	}
	
	handleChangeH(e){
	this.setState({h:e.target.value});
		
	}
	
	render(){
		return(
		<>
			<div>
				<h3><u>Put your values</u>:</h3>
				<form>
					<label for="Width"><b>Width :</b></label>
					<input value={this.state.w}  onChange={this.handleChangeW} id="wdth" name="wdth" /><br /><br />
					<label for="Height"><b>Height:</b></label>
					<input value={this.state.h}  id="hght" name="hght"  onChange={this.handleChangeH} /><br /><br />
				</form>
			</div>
			<div>
				<img src="images/1.jpg" width={this.state.w} height={this.state.h} />
			</div>
		</>
		);
	}
}



ReactDOM.render(
	<VALUES />, document.getElementById('root')
);