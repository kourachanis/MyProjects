
$(document).ready(function(){
	
	var num=[];
	var color=['blue', 'green', 'red'];
	var A=[];
	var chart;
	google.charts.load('current', {packages: ['corechart', 'bar']});
	
	google.charts.setOnLoadCallback(drawGraph);
	var options;
	
	function drawGraph()
	{
		chart = new google.visualization.BarChart(document.getElementById('div1b'));
		A=[
		  ['Color', 'Number', { role: 'style' }],
          ['Blue', 0, 'color:#0000ff;'],            // RGB value
          ['Green', 0, 'color:#00ff00;'],            // English color name
          ['Red', 0, 'color:#ff0000;'],
		];
		
		var data = new google.visualization.arrayToDataTable(A);
		
		options = {
          title: 'Number of circles based on colors:',
		  width: 500,
		  height: 300,
          legend: { position: 'none' },
          chart: { title: 'Colors on Screen',
                    },
          bars: 'vertical', 
          axes: {
            x: {
              0: { side: 'top', label: 'Colors'} 
            }
          },
          bar: { groupWidth: "40%" }
        };
		
		chart.draw(data, options);
	
	}
	
	var t1=setInterval(function(){circle();}, 3000);
	
	
	function circle(){
	
		num=[];
		for(i=0;i<3;i++)
		{
			x=Math.floor(Math.random() * 20)+1;
			num.push(x);
		}
		
		s="<table class=table border=1><tr><th>Number of circles</th><th>Color</th></tr>"
			
		for(i=0;i<3;i++)
		{
			s+="<tr><td>"+num[i]+"</td><td>"+color[i]+"</td></tr>"
		}
			
		s+="</table>"
			
		$("#div1a").html(s);
		
		
		
		var blue=num[0];
		var green=num[1];
		var red=num[2];
				
		c="";
		for (i=0; i<blue; i++)
		{	x=Math.random()*1400+20;
			y=Math.random()*350;		
			c+="<div class='img_circle bluec' style='top:"+y+"px; left:"+x+"px'></div>";
		}
		
		for (i=0; i<green; i++)
		{	x=Math.random()*1400+20;
			y=Math.random()*350;		
			c+="<div class='img_circle greenc' style='top:"+y+"px; left:"+x+"px; '></div>";
		}
		
		for (i=0; i<red; i++)
		{	x=Math.random()*1400+20;
			y=Math.random()*350;		
			c+="<div class='img_circle redc ' style='top:"+y+"px; left:"+x+"px;'></div>";
		}
				
		$("#div2").html(c);
		
		A=[
		  ['Color', 'Number', { role: 'style' }],
		  ['Blue', num[0], '#0000ff'],            
          ['Green', num[1], '#00ff00'],            
          ['Red', num[2], '#ff0000'],	
		];
		var data = new google.visualization.arrayToDataTable(A);

		chart.draw(data, options);
		
	}
	
	
	
});
