create table epixeirisi(
	id int primary key auto_increment not null,
	name varchar(100),
	titlos varchar(300),
	hmer_kataxorisis date,
	city varchar(300),
	diefthinsi varchar(300),
	TK varchar(300),
	id_ypokatastima int,
	id_mitrwo int,
	id_doy int,
	id_epimelitiria int,
	id_elegktes int,
	foreign key (id_ypokatastima) references epixeirisi(id),
	foreign key (id_mitrwo) references mitrwo(id),
	foreign key (id_doy) references doy(id),
	foreign key (id_epimelitiria) references epimelitiria(id),
);

create table mitrwo(
	id int primary key auto_increment not null,
	fyllo enum('Άνδρας','Γυναίκα'),
	fname varchar(300),
	lname varchar(300),
	proswpiko int,
	afm varchar(9),
	CV text
);

create table tilefwna(
	id_mitrwo int,
	tilefwna varchar(20),
	foreign key (id_mitrwo) references mitrwo(id) on delete cascade on update cascade
);

create table doy(
	id int primary key auto_increment not null,
	site varchar(300),
	name varchar(300),
	etos_idrysis int
);

create table epimelitiria(
	id int primary key auto_increment not null,
	name varchar(300),
	eidos enum('Εμπορικό', 'Βιοτεχνικό', 'Επαγγελματικό'),
	edra varchar(300)
);

create table fysika_proswpa(
	id int primary key auto_increment not null,
	name varchar(300),
	afm varchar(9),
	id_mitrwo int,
	id_epixeirisi int,
	foreign key (id_mitrwo) references mitrwo(id) on delete cascade on update cascade,
	foreign key (id_epixeirisi) references epixeirisi(id) on delete cascade on update cascade
);

create table metoxoi(
	id int primary key,
	foreign key (id) references fysika_proswpa(id) on delete cascade on update cascade
);

create table epixeirisi_metoxoi(
	pososto_metoxwn float(3,1),
	melos_symbouliou enum('Ναι', 'Οχι'),
	id_epixeirisi int,
	id_metoxoi int,
	foreign key (id_epixeirisi) references epixeirisi(id) on delete cascade on update cascade,
	foreign key (id_metoxoi) references metoxoi(id) on delete cascade on update cascade
);

create table elegktes(
	id int primary key,
	soel_number varchar(100),
	hmer_enarxis_thiteias date,
	typos enum('Αναπληρωματικός', 'Τακτικός'),
	foreign key (id) references fysika_proswpa(id) on delete cascade on update cascade
);

create table epixeirisi_elegktes(
	hmer_enarxis date,
	hmer_lixis date,
	id_epixeirisi int,
	id_elegktes int,
	foreign key (id_epixeirisi) references epixeirisi(id) on delete cascade on update cascade,
	foreign key (id_elegktes) references elegktes(id) on delete cascade on update cascade
);

create table katastatika(
	id int primary key auto_increment not null,
	dhmosio_arxeio enum('Ναι','Οχι'),
	size_arxeiou float(10,2),
	hmer_ekdosis date,
	apothikeutiko_meros varchar(300),
	id_epixeirisi int,
	foreign key (id_epixeirisi) references epixeirisi(id) on delete cascade on update cascade
);