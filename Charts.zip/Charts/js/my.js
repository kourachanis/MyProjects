	google.charts.load('current', {'packages':['bar']});
	google.charts.load('current', {'packages':['corechart']});
	
	var X=[];
	var Y=[];
	
	$(document).ready(function(){
	
		
		$("#sbt").click(function(){
			X.push($('#valueX').val());
			Y.push($('#valueY').val());
			
			s="<table border=1><tr><th>X</th><th>Y</th><th>Delete</th></tr>"
			
			for(i=0;i<X.length;i++)
			{
				s+="<tr><td>"+X[i]+"</td><td>"+Y[i]+"</td><td><button onclick='del("+i+")'>X</button></td></tr>"
			}
			
			s+="</table>"
			
			$("#div2").html(s);
		});		

		$("#bar").click(function(){
			A=[];
			A.push(["X","Y"]);
			
			for(i=0;i<X.length;i++)
			{
				A.push([X[i],Y[i]/1]);
			}
			var data = google.visualization.arrayToDataTable(A);

			var options = {
			  chart: {
				title: 'X vs Y',
			  },
			  bars: 'horizontal' // Required for Material Bar Charts.
			};

			var chart = new google.charts.Bar(document.getElementById('td1'));

			chart.draw(data, google.charts.Bar.convertOptions(options));
		});
		
		$("#pie").click(function(){
			A=[];
			A.push(["X","Y"]);
			
			for(i=0;i<X.length;i++)
			{
				A.push([X[i],Y[i]/1]);
			}
			
			var data = google.visualization.arrayToDataTable(A);
			 
			var options = {
				title: 'X vs Y',
				is3D: true,
			};

			var chart = new google.visualization.PieChart(document.getElementById('td1'));
			chart.draw(data, options);
		});
		
		$("#donut").click(function(){
			A=[];
			A.push(["X","Y"]);
			
			for(i=0;i<X.length;i++)
			{
				A.push([X[i],Y[i]/1]);
			}
			
			var data = google.visualization.arrayToDataTable(A);
			 
			var options = {
				title: 'X vs Y',
				pieHole: 0.4,
			};

			var chart = new google.visualization.PieChart(document.getElementById('td1'));
			chart.draw(data, options);
		});
		
		$("#scatter").click(function(){
			A=[];
			A.push(["X","Y"]);
			
			for(i=0;i<X.length;i++)
			{
				A.push([X[i],Y[i]/1]);
			}
			
			var data = google.visualization.arrayToDataTable(A);
			 
			var options = {
				title: 'X vs Y',
				hAxis: {title: 'X' },
				vAxis: {title: 'Y'},
				legend: 'none'
			};

			var chart = new google.visualization.ScatterChart(document.getElementById('td1'));

			chart.draw(data, options);
		});
		
	  });
	  
	function del(j){
	
		var X2=[];
		var Y2=[];
	
		for(i=0;i<X.length;i++)
		{
			if(i!=j){
				X2.push(X[i]);
				Y2.push(Y[i]);
			}
		}
		
		X=X2;
		Y=Y2;
		
		s="<table border=1><tr><th>X</th><th>Y</th><th>Delete</th></tr>"
			
		for(i=0;i<X.length;i++)
			{
				s+="<tr><td>"+X[i]+"</td><td>"+Y[i]+"</td><td><button onclick='del("+i+")'>X</button></td></tr>"
			}
			
		s+="</table>"
			
		$("#div2").html(s);
	}