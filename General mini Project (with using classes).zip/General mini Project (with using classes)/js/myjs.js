const data=[
{"code_product":"FF100", "title":"Nike","Description":"Nike-shoes",
"image_front":"images/shoes.png","image_inside":"images/shoes1.png", "price":"120" },
{"code_product":"FF110", "title":"Vans","Description":"Vans-shoes",
"image_front":"images/shoes2.png","image_inside":"images/shoes3.png", "price":"70" },
{"code_product":"FF120", "title":"Adidas","Description":"Walk-shoes",
"image_front":"images/shoes4.png","image_inside":"images/shoes5.jpg", "price":"100" },
{"code_product":"FF130", "title":"Puma","Description":"Running-shoes",
"image_front":"images/shoes6.jpg","image_inside":"images/shoes7.jpg", "price":"140" },
{"code_product":"FF140", "title":"Adidas","Description":"Basketball shoes",
"image_front":"images/shoes8.png","image_inside":"images/shoes9.jpg", "price":"150" },
{"code_product":"FF150", "title":"All Star","Description":"Walk-shoes",
"image_front":"images/shoes10.png","image_inside":"images/shoes11.jpg", "price":"60" },
{"code_product":"FF160", "title":"Nike","Description":"Nice-shoes",
"image_front":"images/shoes12.png","image_inside":"images/shoes13.png", "price":"119" },
{"code_product":"FF170", "title":"Adidas","Description":" Running shoes",
"image_front":"images/shoes14.png","image_inside":"images/shoes15.png", "price":"130" }
];

var products=[];
var sales=[];
var s="";
$(document).ready(function(){
	
for(var i=0;i<8;i++)
{
	products[i]=new PRODUCTS(data[i].code_product,data[i].title,data[i].Description,data[i].image_front,data[i].image_inside,data[i].price);
	products[i].show();
}


$("#send").click(()=>{
		var t=$("#titlem").val();
		var f=$("#fullnamem").val();
		var p=$("#phonem").val();
		
		var sl=new SALES(t,f,p);
		sales.push(sl);
	$("#msg").html("Product send");
	});


$("#showsales").click(()=>{
		h="<table class=table><tr><th>Title</th><th>Fullname</th><th>Phone</th></tr>";
		for (var i=0;i<sales.length;i++)
		{
			h+=sales[i].show();
			
		}
		h+="</table>";
		$("#saleslist").html(h);
		$("#myModal").modal("hide");
	})
});



class PRODUCTS{
	constructor(code_product,title,Description,image_front,image_inside,price){
		this.code_product=code_product;
		this.title=title;
		this.Description=Description;
		this.image_front=image_front;
		this.image_inside=image_inside;
		this.price=price;
	}
	
	show(){
		s+=`<div class='col-md-3' onclick='showmodal("${this.title}")' >
				<p>${this.title}</p><br>
				<img src='${this.image_front}'><br>
				<p>${this.Description}</p>
			</div>`;
				
		$("#here").html(s);
		
	}
		
}

class SALES{
	constructor(title,fullname,phone){
		this.title=title;
		this.fullname=fullname;
		this.phone=phone;
	}
	
	show(){
		var c=`<tr><td>${this.title}</td><td>${this.fullname}</td><td>${this.phone}</td></tr>`;
			
		return c;
		
	}
		
}


function showmodal(a){
	
	$("#myModal").modal("show");
	$("#titlem").val(a);
	$("#msg").html("");
	
}
