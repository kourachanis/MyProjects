<?php
session_start();
$conn=mysqli_connect("localhost","root","","map_example");
mysqli_query($conn,"set names 'utf8'");
?>