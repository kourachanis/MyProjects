<?php
include 'up.php'
?>

<script
    src="https://maps.googleapis.com/maps/api/js?&callback=initMap&v=weekly"
    defer
></script>

<script>

var info;

	function initMap() {
		
  		const myLatLng1 = {  lat:38.2395729630,  lng:21.7617670909 };
		const myLatLng2 = {  lat:38.0320643919,  lng:22.1358103819 };
		const myLatLng3 = {  lat:38.3956825719,  lng:21.8753737862 };
		const myLatLng4 = {  lat:38.1622379167,  lng:21.5060080919 }; 
		const myLatLng5 = {  lat:38.4234639600,  lng:20.5655507126 }; 
		
 		const map = new google.maps.Map(document.getElementById("map"), {
    			zoom: 8,
    			center: myLatLng1,
 			});
			
		info=new google.maps.InfoWindow({
							content: ""
						  });

		var mrk1=new google.maps.Marker({
				position: myLatLng1,
				map,
			title: "Here is Patra!",
			});

		var mrk2=new google.maps.Marker({
				position: myLatLng2,
				map,
			title: "Here is Kalavryta!",
			});
			
		var mrk3=new google.maps.Marker({
				position: myLatLng3,
				map,
			title: "Here is Nafpaktos!",
			});	
			
		var mrk4=new google.maps.Marker({
				position: myLatLng4,
				map,
			title: "Here is Katw Axagia!",
			});	
		
		var mrk5=new google.maps.Marker({
				position: myLatLng5,
				map,
			title: "Here is Fiskardo!",
			});	
			
		mrk1.addListener("click", () => {
			info.open({
				anchor: mrk1,
				map,
			});
			getData(myLatLng1.lat, myLatLng1.lng);
		});
		
		mrk2.addListener("click", () => {
			info.open({
				anchor: mrk2,
				map,
			});
			getData(myLatLng2.lat, myLatLng2.lng);
		});
		
		mrk3.addListener("click", () => {
			info.open({
				anchor: mrk3,
				map,
			});
			getData(myLatLng3.lat, myLatLng3.lng);
		});
		
		mrk4.addListener("click", () => {
			info.open({
				anchor: mrk4,
				map,
			});
			getData(myLatLng4.lat, myLatLng4.lng);
		});
		
		mrk5.addListener("click", () => {
			info.open({
				anchor: mrk5,
				map,
			});
			getData(myLatLng5.lat, myLatLng5.lng);
		});
		
	}
	
	window.initMap = initMap;
	
	function getData(lat,lng)
	{
		const settings = {
			async: true,
			crossDomain: true,
			url: 'https://weatherapi-com.p.rapidapi.com/current.json?q='+lat+'%2C'+lng,
			method: 'GET',
			headers: {
				'X-RapidAPI-Key': '7074115b02mshd7ae2536ffadb99p1008a8jsne2bb06bcdc2a',
				'X-RapidAPI-Host': 'weatherapi-com.p.rapidapi.com'
			}
		};

		$.ajax(settings).done(function (response) {
			ht="Place:"+response.location.name+"  Temp(C):"+response.current.temp_c+"  Wind:"+response.current.wind_dir+response.current.wind_kph;
			info.setContent(ht);
		});	
	}
</script>


<div class=container id=id1>
	<h1>My Map</h1>
</div>

<div class=container-fluid id=map>

</div>

